https://github.com/wirgeen/dnd5e-traduction-full/releases/download/1.0.0/module.json
